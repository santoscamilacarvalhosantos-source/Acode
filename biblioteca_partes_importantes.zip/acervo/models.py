from django.db import models


class Autor(models.Model):
    nome = models.CharField("Nome", max_length=100)
    nacionalidade = models.CharField("Nacionalidade", max_length=50, blank=True)

    class Meta:
        ordering = ["nome"]
        verbose_name_plural = "autores"

    def __str__(self):
        return self.nome


class Livro(models.Model):
    titulo = models.CharField("Título", max_length=150)
    ano_publicacao = models.PositiveIntegerField("Ano de publicação")
    disponivel = models.BooleanField("Disponível", default=True)
    # Relacionamento: um autor pode ter vários livros
    autor = models.ForeignKey(
        Autor,
        on_delete=models.PROTECT,  # impede apagar autor que ainda tem livros
        related_name="livros",
        verbose_name="Autor",
    )

    class Meta:
        ordering = ["titulo"]

    def __str__(self):
        return self.titulo
