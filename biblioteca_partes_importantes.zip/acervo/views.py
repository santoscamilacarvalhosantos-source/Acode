from django.contrib import messages
from django.db.models import ProtectedError
from django.shortcuts import get_object_or_404, redirect, render

from .forms import AutorForm, LivroForm
from .models import Autor, Livro


def home(request):
    contexto = {
        "total_autores": Autor.objects.count(),
        "total_livros": Livro.objects.count(),
    }
    return render(request, "acervo/home.html", contexto)


# ---------- AUTORES ----------
def autor_list(request):  # READ (lista)
    autores = Autor.objects.all()
    return render(request, "acervo/autor_list.html", {"autores": autores})


def autor_create(request):  # CREATE
    form = AutorForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Autor cadastrado com sucesso!")
        return redirect("autor_list")
    return render(request, "acervo/form.html", {"form": form, "titulo": "Novo autor", "voltar": "autor_list"})


def autor_update(request, pk):  # UPDATE
    autor = get_object_or_404(Autor, pk=pk)
    form = AutorForm(request.POST or None, instance=autor)
    if form.is_valid():
        form.save()
        messages.success(request, "Autor atualizado com sucesso!")
        return redirect("autor_list")
    return render(request, "acervo/form.html", {"form": form, "titulo": "Editar autor", "voltar": "autor_list"})


def autor_delete(request, pk):  # DELETE
    autor = get_object_or_404(Autor, pk=pk)
    if request.method == "POST":
        try:
            autor.delete()
            messages.success(request, "Autor excluído com sucesso!")
        except ProtectedError:
            messages.error(request, "Não é possível excluir: este autor possui livros cadastrados.")
        return redirect("autor_list")
    return render(request, "acervo/confirm_delete.html", {"objeto": autor, "voltar": "autor_list"})


# ---------- LIVROS ----------
def livro_list(request):  # READ (lista + busca)
    busca = request.GET.get("q", "")
    livros = Livro.objects.select_related("autor")
    if busca:
        livros = livros.filter(titulo__icontains=busca)
    return render(request, "acervo/livro_list.html", {"livros": livros, "busca": busca})


def livro_create(request):  # CREATE
    form = LivroForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Livro cadastrado com sucesso!")
        return redirect("livro_list")
    return render(request, "acervo/form.html", {"form": form, "titulo": "Novo livro", "voltar": "livro_list"})


def livro_update(request, pk):  # UPDATE
    livro = get_object_or_404(Livro, pk=pk)
    form = LivroForm(request.POST or None, instance=livro)
    if form.is_valid():
        form.save()
        messages.success(request, "Livro atualizado com sucesso!")
        return redirect("livro_list")
    return render(request, "acervo/form.html", {"form": form, "titulo": "Editar livro", "voltar": "livro_list"})


def livro_delete(request, pk):  # DELETE
    livro = get_object_or_404(Livro, pk=pk)
    if request.method == "POST":
        livro.delete()
        messages.success(request, "Livro excluído com sucesso!")
        return redirect("livro_list")
    return render(request, "acervo/confirm_delete.html", {"objeto": livro, "voltar": "livro_list"})
